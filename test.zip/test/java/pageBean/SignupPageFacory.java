package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class SignupPageFacory {
	WebDriver driver;
	
	@FindBy(xpath="/html/body/form/p[1]/input")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(xpath="/html/body/form/p[2]/input")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(xpath="/html/body/form/p[3]/input")
	@CacheLookup
	WebElement email;
	
	@FindBy(xpath="/html/body/form/p[4]/input")
	@CacheLookup
	WebElement phone;
	
	@FindBy(xpath="/html/body/form/p[5]/input")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath="/html/body/form/p[6]/input")
	@CacheLookup
	WebElement cnfrmpassword;
	
	
	@FindBy(xpath="/html/body/form/p[7]/input")
	@CacheLookup
	WebElement address;
	
	@FindBy(xpath="/html/body/form/p[8]/input")
	@CacheLookup
	WebElement balance;
	
	@FindBy(xpath="/html/body/form/p[9]/input[1]")
	@CacheLookup
	WebElement submit;

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		this.submit.click();
	}

	public SignupPageFacory(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getCnfrmpassword() {
		return cnfrmpassword;
	}

	public void setCnfrmpassword(String cnfrmpassword) {
		this.cnfrmpassword.sendKeys(cnfrmpassword);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance.sendKeys(balance);
	}
	
	


}
