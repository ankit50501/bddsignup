package signup;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.SignupPageFacory;

public class SignupStepDefinition {

	private WebDriver driver;
	private SignupPageFacory signup;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Harry Rana\\Desktop\\workspace-sts\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("^user is on 'capstore_signup' page$")
	public void user_is_on_capstore_signup_page() throws Throwable{
		driver.get("C:\\Users\\Harry Rana\\Desktop\\workspace-sts\\New folder\\BDDCaseStudyFinal\\capstore_signup.html");
		signup = new SignupPageFacory(driver);
		
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() {
		signup.setFirstName("");
		signup.setSubmit();
	}

	@Then("^displays 'Please enter your first name\\.'$")
	public void displays_Please_enter_your_first_name() {
		String expectedMessage="Please enter your first name.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() {
		signup.setFirstName("Ankit");
		signup.setLastName("");
		signup.setSubmit();
	}

	@Then("^displays 'Please enter your last name\\.'$")
	public void displays_Please_enter_your_last_name() {
		String expectedMessage="Please enter your last name.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email(){
		signup.setFirstName("Ankit");
		signup.setLastName("Arora");
		signup.setEmail("");
		signup.setSubmit();
	}

	@Then("^display 'Please enter a valid email address\\.'$")
	public void display_Please_enter_a_valid_email_address() {
		String expectedMessage="Please enter a valid email address.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number(){
		signup.setFirstName("Ankit");
		signup.setLastName("Arora");
		signup.setEmail("ankit@gmail.com");
		signup.setPhone("");
		signup.setSubmit();
	}

	@Then("^display 'Please enter your telephone number\\.'$")
	public void display_Please_enter_your_telephone_number(){
		String expectedMessage="Please enter your telephone number.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong password$")
	public void user_enters_wrong_password(){
		signup.setFirstName("Ankit");
		signup.setLastName("Arora");
		signup.setEmail("ankit@gmail.com");
		signup.setPhone("7404183303");
		signup.setPassword("");
		signup.setSubmit();
	}

	@Then("^display 'Please enter your password'$")
	public void display_Please_enter_your_password() {
		String expectedMessage="Please enter your password";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong confirmPassword$")
	public void user_enters_wrong_confirmPassword() {
		signup.setFirstName("Ankit");
		signup.setLastName("Arora");
		signup.setEmail("ankit@gmail.com");
		signup.setPhone("7404183303");
		signup.setPassword("ankit123#");
		signup.setCnfrmpassword("");
		signup.setSubmit();
	}

	@Then("^display 'Please enter your confirm password'$")
	public void display_Please_enter_your_confirm_password(){
		String expectedMessage="Please enter your confirm password";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong address$")
	public void user_enters_wrong_address(){
		signup.setFirstName("Ankit");
		signup.setLastName("Arora");
		signup.setEmail("ankit@gmail.com");
		signup.setPhone("7404183303");
		signup.setPassword("ankit123#");
		signup.setCnfrmpassword("ankit123#");
		signup.setAddress("");
		signup.setSubmit();
	}

	@Then("^display 'Please enter your address\\.'$")
	public void display_Please_enter_your_address(){
		String expectedMessage="Please enter your address.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong balance$")
	public void user_enters_wrong_balance() {
		signup.setFirstName("Ankit");
		signup.setLastName("Arora");
		signup.setEmail("ankit@gmail.com");
		signup.setPhone("7404183303");
		signup.setPassword("ankit123#");
		signup.setCnfrmpassword("ankit123#");
		signup.setAddress("Chandigarh");
		signup.setBalance("");
		signup.setSubmit();
	}

	@Then("^display 'Please enter your balance\\.'$")
	public void display_Please_enter_your_balance(){
		String expectedMessage="Please enter your balance.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}


}
